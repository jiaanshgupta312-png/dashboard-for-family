// Sample family members data
const familyMembers = [
    { name: 'Mom', emoji: '👩', status: 'Home' },
    { name: 'Dad', emoji: '👨', status: 'Work' },
    { name: 'Sarah', emoji: '👧', status: 'School' },
    { name: 'Tommy', emoji: '👦', status: 'Sports' }
];

// Sample tasks
const tasks = [
    { text: 'Grocery shopping', priority: 'high', completed: false },
    { text: 'Pay bills', priority: 'high', completed: false },
    { text: 'Family dinner at 6pm', priority: 'medium', completed: false },
    { text: 'Clean the house', priority: 'medium', completed: false },
    { text: 'Watch movie night', priority: 'low', completed: false }
];

let currentDate = new Date();

// Initialize on page load
function init() {
    updateDateTime();
    renderCalendar();
    renderFamilyMembers();
    renderTasks();
    simulateWeather();
    setInterval(updateDateTime, 1000);
}

// Update date and time
function updateDateTime() {
    const now = new Date();
    const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
    
    document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', dateOptions);
    document.getElementById('currentTime').textContent = now.toLocaleTimeString('en-US', timeOptions);
}

// Render calendar
function renderCalendar() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    document.getElementById('monthYear').textContent = 
        new Date(year, month).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const daysInPrevMonth = new Date(year, month, 0).getDate();
    
    let daysHTML = '';
    
    // Previous month days
    for (let i = firstDay - 1; i >= 0; i--) {
        daysHTML += `<div class="day other-month">${daysInPrevMonth - i}</div>`;
    }
    
    // Current month days
    const today = new Date();
    for (let day = 1; day <= daysInMonth; day++) {
        const isToday = day === today.getDate() && 
                       month === today.getMonth() && 
                       year === today.getFullYear();
        daysHTML += `<div class="day ${isToday ? 'today' : ''}">${day}</div>`;
    }
    
    // Next month days
    const totalCells = firstDay + daysInMonth;
    const remainingCells = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
    for (let day = 1; day <= remainingCells; day++) {
        daysHTML += `<div class="day other-month">${day}</div>`;
    }
    
    document.getElementById('calendarDays').innerHTML = daysHTML;
}

// Calendar navigation
function previousMonth() {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar();
}

function nextMonth() {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar();
}

// Render family members
function renderFamilyMembers() {
    const membersHTML = familyMembers.map(member => `
        <div class="member-card">
            <div class="member-avatar">${member.emoji}</div>
            <div class="member-name">${member.name}</div>
            <div class="member-status">${member.status}</div>
        </div>
    `).join('');
    
    document.getElementById('familyMembers').innerHTML = membersHTML;
}

// Render tasks
function renderTasks() {
    const tasksHTML = tasks.map((task, index) => `
        <li class="task-item ${task.completed ? 'completed' : ''}">
            <input type="checkbox" class="task-checkbox" 
                   ${task.completed ? 'checked' : ''} 
                   onchange="toggleTask(${index})">
            <span class="task-text">${task.text}</span>
            <span class="task-priority priority-${task.priority}">${task.priority}</span>
        </li>
    `).join('');
    
    document.getElementById('tasksList').innerHTML = tasksHTML;
}

// Toggle task completion
function toggleTask(index) {
    tasks[index].completed = !tasks[index].completed;
    renderTasks();
}

// Add new task
function addTask() {
    const input = document.getElementById('taskInput');
    if (input.value.trim()) {
        tasks.push({
            text: input.value,
            priority: 'medium',
            completed: false
        });
        input.value = '';
        renderTasks();
    }
}

// Allow Enter key to add task
document.addEventListener('keypress', function(e) {
    if (e.key === 'Enter' && document.getElementById('taskInput') === document.activeElement) {
        addTask();
    }
});

// Simulate weather (in real app, use API)
function simulateWeather() {
    const temps = [68, 72, 75, 70, 65];
    const descs = ['Sunny', 'Cloudy', 'Partly Cloudy', 'Rainy', 'Stormy'];
    const random = Math.floor(Math.random() * temps.length);
    
    document.getElementById('temperature').textContent = temps[random] + '°F';
    document.getElementById('weatherDesc').textContent = descs[random];
    document.getElementById('windSpeed').textContent = Math.floor(Math.random() * 20) + 5 + ' mph';
    document.getElementById('humidity').textContent = Math.floor(Math.random() * 40) + 40 + '%';
    document.getElementById('visibility').textContent = Math.floor(Math.random() * 5) + 8 + ' mi';
}

// Start the app when page loads
window.addEventListener('load', init);